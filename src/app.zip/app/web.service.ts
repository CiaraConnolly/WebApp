import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class WebService {
    private countryID: any

    constructor(private http: HttpClient) {

    }

    show_all_countries(page: number) { 
        return this.http.get('http://localhost:5000/api/v1.0/countries?pn=' + page);
    }

    get_total_pages() { 
        return this.http.get('http://localhost:5000/api/v2.0/countries');
    }

    show_one_country(id: any) {
        this.countryID = id;
        return this.http.get('http://localhost:5000/api/v1.0/countries/'+id);
    }

    fetch_all_teams(id: any) {
        return this.http.get('http://localhost:5000/api/v1.0/countries/'+id + '/teams');
    }

    postTeam(team: any) {
        let postData = new FormData();
        postData.append("Name", team.Name);
        postData.append("NOC", team.NOC);
        postData.append("Discipline", team.Discipline);
        postData.append("Event", team.Event);

        return this.http.post('http://localhost:5000/api/v1.0/countries/' + this.countryID + '/teams', postData); 
    }

}